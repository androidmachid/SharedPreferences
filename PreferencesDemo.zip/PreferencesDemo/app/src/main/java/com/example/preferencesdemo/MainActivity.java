package com.example.preferencesdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textView);
        // value retrieve
        SharedPreferences sharedPreferences1 = getSharedPreferences("MyPref",MODE_PRIVATE);
        String s1 = sharedPreferences1.getString("name","");

        textView.setText(s1);

        EditText editText = findViewById(R.id.editTextTextPersonName);

        Button  button = findViewById(R.id.button);

        // value store
        SharedPreferences sharedPreferences = getSharedPreferences("MyPref",MODE_PRIVATE);
        SharedPreferences.Editor test = sharedPreferences.edit();






        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = editText.getText().toString();
                textView.setText(s);
                test.putString("name",s);
                test.commit();
                test.putInt("number",999999999);
            }
        });
    }
}